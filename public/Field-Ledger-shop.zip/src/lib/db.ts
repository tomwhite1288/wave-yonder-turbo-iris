import { pendingMigrations } from "../../scripts/migration-plan.mjs";
import { mkdirSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

/** Which database backend is active. */
export type DbSource = "neon" | "pglite";

function readDatabaseUrl(): string | undefined {
  if (typeof process === "undefined") return undefined;
  const raw = process.env.DATABASE_URL?.trim();
  if (!raw) return undefined;
  // Imported placeholder from netlify.env is not a real database.
  if (/USER:PASSWORD|ep-XXXX|REPLACE|changeme|YOUR-|PASSWORD@/i.test(raw)) return undefined;
  if (!/^postgres(ql)?:\/\//i.test(raw)) return undefined;
  return raw;
}

function isServerlessRuntime(): boolean {
  if (typeof process === "undefined") return false;
  return Boolean(
    process.env.NETLIFY ||
      process.env.AWS_LAMBDA_FUNCTION_NAME ||
      process.env.LAMBDA_TASK_ROOT ||
      process.env.VERCEL,
  );
}

/**
 * Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
 * sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
 * the app has a working database even with nothing configured — the live preview
 * included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
 *
 * Read lazily so Netlify/Vercel functions see runtime env, not a build-time empty
 * string. Without a real Neon URL the embedded PGLite database is used, including
 * on Netlify (persisted to Netlify Blobs when that context exists).
 */
export function currentDbSource(): DbSource {
  return readDatabaseUrl() ? "neon" : "pglite";
}

export const dbSource: DbSource = currentDbSource();

/**
 * Minimal shared SQL surface, satisfied by both Neon and PGLite. Both the
 * tagged-template and `.query()` forms resolve to an array of row objects:
 *
 *   const sql = await getSql();
 *   const rows = await sql`select * from todos where id = ${id}`; // parameterized
 *   const rows2 = await sql.query("select * from todos where id = $1", [id]);
 */
export interface Sql {
  <T = Record<string, unknown>>(
    strings: TemplateStringsArray,
    ...values: unknown[]
  ): Promise<T[]>;
  query<T = Record<string, unknown>>(
    text: string,
    params?: unknown[],
  ): Promise<T[]>;
}

/**
 * Init state lives on globalThis as promises: dev HMR creates new instances of
 * this module, and two instances racing module-level state would open a second
 * pool or run two concurrent PGLite migration passes (whose duplicate
 * `_migrations` insert rejects — and would get memoized, poisoning every later
 * `getSql()`). A failed init clears its slot so the next call retries.
 */
const globalRef = globalThis as typeof globalThis & {
  __pgSqlPromise__?: Promise<Sql>;
  __pgliteInstance__?: Promise<import("@electric-sql/pglite").PGlite>;
  __pgliteMigrateChain__?: Promise<void>;
};

/**
 * Result-type parity: Postgres sends every value as text plus a type OID — the
 * JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
 * int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
 * JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
 * production return identical, JSON-safe shapes:
 *   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
 *                                   `::text` if you ever need huge integers)
 *   date                         -> 'YYYY-MM-DD' string
 *   interval                     -> Postgres interval text
 * numeric already comes back as a string on both (arbitrary precision).
 */
const OID_INT8 = 20;
const OID_DATE = 1082;
const OID_INTERVAL = 1186;
const identity = (v: string) => v;

type Run = <T>(text: string, params: unknown[]) => Promise<T[]>;

/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run: Run): Sql {
  const sql = (async <T = Record<string, unknown>>(
    strings: TemplateStringsArray,
    ...values: unknown[]
  ): Promise<T[]> => {
    // Rebuild with $1, $2, … placeholders so values stay parameterized.
    let text = strings[0];
    for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
    return run<T>(text, values);
  }) as unknown as Sql;
  sql.query = <T = Record<string, unknown>>(text: string, params: unknown[] = []) =>
    run<T>(text, params);
  return sql;
}

function createNeonSql(): Promise<Sql> {
  globalRef.__pgSqlPromise__ ??= (async () => {
    // Regular Postgres driver: node-postgres (`pg`) — works directly with Neon's
    // pooled endpoint. One pool per process; warm serverless instances reuse it.
    const { Pool, types } = await import("pg");
    types.setTypeParser(OID_INT8, Number);
    types.setTypeParser(OID_DATE, identity);
    types.setTypeParser(OID_INTERVAL, identity);
    const connectionString = readDatabaseUrl();
    if (!connectionString) throw new Error("DATABASE_URL missing");
    const pool = new Pool({
      connectionString,
      ssl:
        /sslmode=disable/i.test(connectionString)
          ? undefined
          : { rejectUnauthorized: false },
    });
    return toSql(async <T>(text: string, params: unknown[]) => {
      const res = await pool.query(text, params);
      return res.rows as T[];
    });
  })().catch((err) => {
    globalRef.__pgSqlPromise__ = undefined;
    throw err;
  });
  return globalRef.__pgSqlPromise__;
}

function localDumpPath() {
  return path.join(process.cwd(), "data", "pglite.dump");
}

function localDataDir() {
  return path.join(process.cwd(), "data", "pglite");
}

async function loadPgliteDump(): Promise<Blob | File | undefined> {
  if (isServerlessRuntime()) {
    try {
      const { getStore } = await import("@netlify/blobs");
      const store = getStore({ name: "fieldledger-db", consistency: "strong" });
      const data = await store.get("pglite.dump", { type: "blob" });
      if (data) return data;
    } catch {
      /* no blobs */
    }
  }
  try {
    const file = localDumpPath();
    if (!existsSync(file)) return undefined;
    const buf = readFileSync(file);
    return new Blob([buf], { type: "application/gzip" });
  } catch {
    return undefined;
  }
}

let persistTimer: ReturnType<typeof setTimeout> | null = null;
function schedulePglitePersist(pg: import("@electric-sql/pglite").PGlite) {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    void persistPgliteNow();
  }, 250);
}

/** Flush the shop database so the next request still has the office login and tickets. */
export async function persistPgliteNow() {
  if (typeof window !== "undefined") return;
  if (currentDbSource() !== "pglite") return;
  try {
    const pg = await globalRef.__pgliteInstance__;
    if (!pg) return;
    const dump = await pg.dumpDataDir("gzip");
    mkdirSync(path.dirname(localDumpPath()), { recursive: true });
    const raw =
      dump instanceof Blob
        ? Buffer.from(await dump.arrayBuffer())
        : Buffer.from((dump as { tarball?: Uint8Array }).tarball ?? (dump as Uint8Array));
    writeFileSync(localDumpPath(), raw);
    if (isServerlessRuntime()) {
      try {
        const { getStore } = await import("@netlify/blobs");
        const store = getStore({ name: "fieldledger-db", consistency: "strong" });
        await store.set("pglite.dump", dump);
      } catch {
        /* preview / no blobs */
      }
    }
  } catch (err) {
    console.error("[db] PGLite persist skipped:", err);
  }
}

async function createPgliteSql(): Promise<Sql> {
  // Embedded Postgres, imported on demand so it never loads on the Neon path.
  // One in-memory instance per process, shared across HMR module instances, so
  // data survives source edits (it resets on dev-server restart).
  globalRef.__pgliteInstance__ ??= (async () => {
    const { PGlite } = await import("@electric-sql/pglite");
    const parsers = {
      [OID_INT8]: Number,
      [OID_DATE]: identity,
      [OID_INTERVAL]: identity,
    };
    const loadDataDir = await loadPgliteDump();
    let pg: import("@electric-sql/pglite").PGlite;
    try {
      if (!isServerlessRuntime()) {
        const dir = localDataDir();
        mkdirSync(dir, { recursive: true });
        pg = new PGlite(dir, { loadDataDir, parsers, relaxedDurability: true });
      } else {
        pg = new PGlite({ loadDataDir, parsers, relaxedDurability: true });
      }
      await pg.waitReady;
    } catch {
      pg = new PGlite({ loadDataDir, parsers });
      await pg.waitReady;
    }
    await pg.exec(
      "create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())",
    );
    return pg;
  })().catch((err) => {
    globalRef.__pgliteInstance__ = undefined;
    throw err;
  });
  const pg = await globalRef.__pgliteInstance__;

  // Apply migrations/ (the single schema source) so preview matches production.
  // SQL is inlined by the bundler via import.meta.glob (no runtime fs); applied
  // files are tracked in _migrations. The glob does not descend, so the opt-in
  // auth schema under migrations/auth/ stays out. Runs once per module instance
  // — so an HMR reload after adding a migration file applies it live — with
  // passes serialized on a global chain so concurrent callers never
  // double-apply. Accountability + office-sync live in 0006/0007.

  const migrate = async (): Promise<void> => {
    const migrations = import.meta.glob("/migrations/*.sql", {
      query: "?raw",
      import: "default",
      eager: true,
    }) as Record<string, string>;
    const doneRows = await pg.query<{ name: string }>(
      "select name from _migrations",
    );
    const done = doneRows.rows.map((r) => r.name);
    for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) {
      // Apply + record atomically (parity with scripts/migrate.mjs) so a failed
      // statement can't leave a file half-applied but untracked.
      await pg.transaction(async (tx) => {
        await tx.exec(migrations[path]);
        await tx.query("insert into _migrations (name) values ($1)", [name]);
      });
    }
  };
  const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve())
    .catch(() => undefined) // an earlier failed pass must not wedge the chain
    .then(migrate);
  globalRef.__pgliteMigrateChain__ = pass;
  await pass;
  schedulePglitePersist(pg);

  return toSql(async <T>(text: string, params: unknown[]) => {
    const result = await pg.query<T>(text, params);
    if (!/^\s*select\b/i.test(text)) schedulePglitePersist(pg);
    return result.rows;
  });
}

let sqlPromise: Promise<Sql> | null = null;

async function createSql(): Promise<Sql> {
  if (typeof window !== "undefined") {
    throw new Error(
      "@/lib/db is server-only — call getSql() from a createServerFn handler " +
        "or a server route loader, never from client code.",
    );
  }
  if (currentDbSource() === "neon") return createNeonSql();
  return createPgliteSql();
}

/**
 * Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
 * otherwise the local PGLite fallback. Memoized — safe to call per request.
 *
 * Schema comes from `migrations/*.sql`, auto-applied before the first query on
 * both backends — define tables there, never inline in server functions.
 */
export function getSql(): Promise<Sql> {
  sqlPromise ??= createSql().catch((err) => {
    sqlPromise = null; // don't memoize failures — let the next call retry
    throw err;
  });
  return sqlPromise;
}

/**
 * The shared PGLite instance (preview only), with `migrations/*.sql` applied.
 * Lets Better Auth persist to the SAME embedded DB as app data in preview (via a
 * Kysely dialect). Throws when `DATABASE_URL` is set (that path uses Neon).
 */
export async function getPglite(): Promise<import("@electric-sql/pglite").PGlite> {
  if (currentDbSource() !== "pglite") {
    throw new Error("getPglite() is only available on the PGLite fallback (no DATABASE_URL)");
  }
  await getSql();
  const pg = await globalRef.__pgliteInstance__;
  if (!pg) throw new Error("PGLite instance failed to initialize");
  return pg;
}

/**
 * Finish DB bootstrap before the server handles traffic.
 *
 * - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
 *   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
 * - **Neon**: no-op (pool is created lazily on first query).
 *
 * Vite `configureServer` awaits this at dev startup; production imports of this
 * module kick it off immediately (see bottom of file).
 */
export function ensureDbReady(): Promise<void> {
  if (currentDbSource() !== "pglite") return Promise.resolve();
  return getSql().then(() => undefined);
}

// Preview-only eager start. On Netlify/Vercel, PGLite boots lazily on first query
// so a missing WASM/blobs context cannot take down the whole site at import time.
const globalBoot = globalThis as typeof globalThis & {
  __pgBootstrapPromise__?: Promise<void>;
};
if (typeof window === "undefined" && !isServerlessRuntime() && currentDbSource() === "pglite") {
  globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
    globalBoot.__pgBootstrapPromise__ = undefined;
    console.error("[db] PGLite bootstrap failed:", err);
  });
}
