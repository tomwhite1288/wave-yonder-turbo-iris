import { createFileRoute } from "@tanstack/react-router";
import { CodeBookApp } from "@/components/code-book";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Code Book" },
      { name: "description", content: "Offline HVAC and plumbing code lookup." },
      { name: "theme-color", content: "#0B0E11" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-title", content: "Code Book" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "mobile-web-app-capable", content: "yes" },
    ],
    links: [
      { rel: "manifest", href: "/book-manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: CodeBookApp,
});
