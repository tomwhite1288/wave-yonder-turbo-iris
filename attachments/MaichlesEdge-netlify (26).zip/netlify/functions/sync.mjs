import { authorizeSyncWrite, readSession } from "./lib/auth-core.mjs";

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type, x-sync-key",
  "access-control-allow-methods": "GET, PUT, OPTIONS",
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", ...cors },
  });
}

function blobsContext() {
  const raw = globalThis.netlifyBlobsContext || process.env.NETLIFY_BLOBS_CONTEXT || "";
  if (!raw) return null;
  const tryParse = (s) => {
    try {
      return JSON.parse(s);
    } catch {
      return null;
    }
  };
  let parsed = tryParse(raw);
  if (parsed && (parsed.siteID || parsed.token || parsed.edgeURL)) return parsed;
  try {
    parsed = tryParse(Buffer.from(raw, "base64").toString("utf8"));
  } catch {
    /* ignore */
  }
  return parsed;
}

function blobUrls(ctx, key) {
  const store = "maichlesedge";
  const path = `/${ctx.siteID}/${store}/${encodeURIComponent(key)}`;
  const headers = { authorization: `Bearer ${ctx.token}` };
  if (ctx.edgeURL) {
    const base = ctx.uncachedEdgeURL || ctx.edgeURL;
    return { url: new URL(path, base).toString(), headers, mode: "edge" };
  }
  const api = (ctx.apiURL || "https://api.netlify.com").replace(/\/$/, "");
  return { url: `${api}/api/v1/blobs${path}`, headers: { ...headers, accept: "application/json;type=signed-url" }, mode: "api" };
}

async function blobGet(key) {
  const ctx = blobsContext();
  if (!ctx?.siteID || !ctx?.token) throw new Error("Blobs context missing (siteID/token)");
  const req = blobUrls(ctx, key);
  if (req.mode === "edge") {
    const res = await fetch(req.url, { headers: req.headers });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error("blob GET " + res.status + " " + (await res.text()).slice(0, 180));
    return res.json();
  }
  const sign = await fetch(req.url, { headers: req.headers, method: "GET" });
  if (sign.status === 404) return null;
  if (!sign.ok) throw new Error("blob sign GET " + sign.status);
  const { url } = await sign.json();
  const res = await fetch(url);
  if (res.status === 404) return null;
  if (!res.ok) throw new Error("blob signed GET " + res.status);
  return res.json();
}

async function blobPut(key, value) {
  const ctx = blobsContext();
  if (!ctx?.siteID || !ctx?.token) throw new Error("Blobs context missing (siteID/token)");
  const body = JSON.stringify(value);
  const req = blobUrls(ctx, key);
  if (req.mode === "edge") {
    const res = await fetch(req.url, {
      method: "PUT",
      headers: { ...req.headers, "content-type": "application/json", "cache-control": "max-age=0, stale-while-revalidate=60" },
      body,
    });
    if (!res.ok) throw new Error("blob PUT " + res.status + " " + (await res.text()).slice(0, 180));
    return;
  }
  const sign = await fetch(req.url, { headers: req.headers, method: "PUT" });
  if (!sign.ok) throw new Error("blob sign PUT " + sign.status);
  const { url } = await sign.json();
  const res = await fetch(url, { method: "PUT", headers: { "content-type": "application/json" }, body });
  if (!res.ok) throw new Error("blob signed PUT " + res.status);
}

function mergeById(a, b, id, time) {
  const m = new Map();
  for (const x of [...(a || []), ...(b || [])]) {
    const k = id(x);
    if (!k) continue;
    const prev = m.get(k);
    if (!prev || (time(x) || 0) > (time(prev) || 0)) m.set(k, x);
  }
  return [...m.values()];
}

function mergeAccounts(a = {}, b = {}) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    const cur = out[k];
    if (!cur) out[k] = v;
    else {
      const remotePinAt = v.pinUpdatedAt || 0;
      const localPinAt = cur.pinUpdatedAt || 0;
      out[k] = {
        ...cur,
        ...v,
        pin: "",
        pinUpdatedAt: Math.max(remotePinAt, localPinAt),
        layoutMode: cur.layoutMode || v.layoutMode,
        themeId: v.themeId || cur.themeId,
        themeAccent: v.themeAccent || cur.themeAccent,
      };
    }
  }
  return out;
}

function mergeData(local, remote) {
  if (!local) return remote;
  if (!remote) return local;
  const ls = local.settings || {};
  const rs = remote.settings || {};
  return {
    ...local,
    ...remote,
    codes: (remote.codes?.length || 0) >= (local.codes?.length || 0) ? remote.codes : local.codes,
    invoices: mergeById(local.invoices, remote.invoices, (i) => i.id, (i) => i.updatedAt || i.createdAt || 0),
    accounts: mergeAccounts(local.accounts, remote.accounts),
    customers: mergeById(local.customers, remote.customers, (c) => c.id, () => 0),
    employees: mergeById(local.employees, remote.employees, (e) => e.id, () => 0),
    settings: {
      ...ls,
      ...rs,
      skipPicker: ls.skipPicker ?? rs.skipPicker,
      invoiceHeaderImage: (ls.invoiceHeaderImage || "").startsWith("data:") ? ls.invoiceHeaderImage : rs.invoiceHeaderImage || ls.invoiceHeaderImage,
      syncCloudKey: ls.syncCloudKey || rs.syncCloudKey || "",
      syncKey: ls.syncKey || rs.syncKey,
      unlockKey: ls.unlockKey || rs.unlockKey,
    },
    timeEntries: mergeById(local.timeEntries, remote.timeEntries, (t) => t.id, (t) => t.in || 0),
    recoveryCode: remote.recoveryCode || local.recoveryCode,
    parts: mergeById(local.parts, remote.parts, (p) => p.sku, () => 0),
    purchaseOrders: mergeById(local.purchaseOrders, remote.purchaseOrders, (p) => p.id, (p) => p.at || 0),
    recurrences: mergeById(local.recurrences, remote.recurrences, (r) => r.id, () => 0),
    customReminders: mergeById(local.customReminders, remote.customReminders, (r) => r.id, (r) => r.at || 0),
    messages: mergeById(local.messages, remote.messages, (m) => m.id, (m) => m.at || 0),
    stockRequests: mergeById(local.stockRequests, remote.stockRequests, (r) => r.id, (r) => r.at || 0),
    notices: mergeById(local.notices, remote.notices, (n) => n.id, (n) => n.at || 0),
    chatRead: { ...(remote.chatRead || {}), ...(local.chatRead || {}) },
    mutedReminders: { ...(remote.mutedReminders || {}), ...(local.mutedReminders || {}) },
  };
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  const auth = await readSession(req).catch(() => null);
  if (!auth) return json({ error: "Sign in required" }, 401);
  const key = (req.headers.get("x-sync-key") || "").trim();
  if (key.length < 6) return json({ error: "Company key required" }, 401);

  try {
    if (req.method === "GET") {
      const data = await blobGet(key);
      return json(data || { rev: 0, at: 0, data: null });
    }
    if (req.method === "PUT") {
      const body = await req.json();
      const cur = (await blobGet(key)) || { rev: 0, at: 0, data: null };
      const denied = authorizeSyncWrite(auth.user, cur, body);
      if (denied) return json({ error: denied }, 403);
      const next = {
        rev: Math.max(cur.rev || 0, body.rev || 0) + 1,
        at: Date.now(),
        data: mergeData(cur.data, body.data),
        actor: auth.user.user,
      };
      await blobPut(key, next);
      return json(next);
    }
    return json({ error: "Method" }, 405);
  } catch (err) {
    return json({ error: String(err && err.message ? err.message : err) }, 500);
  }
};

export const config = { path: "/api/sync" };
