import {
  cookieHeader,
  corsHeaders,
  createSession,
  ensureDemoUsers,
  hashPassword,
  jsonRes,
  loadSessions,
  loadUsers,
  newId,
  publicUser,
  readSession,
  recordAttempt,
  revokeSession,
  revokeUserSessions,
  saveUsers,
  sha256,
  verifyPassword,
  checkAttempts,
  blobGet,
  blobPut,
  RESETS_KEY,
} from "./lib/auth-core.mjs";

function parseBody(req) {
  return req.json().catch(() => ({}));
}

export default async function handler(req) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (req.method !== "POST" && req.method !== "GET") return jsonRes(req, { error: "Method" }, 405);

  let action = new URL(req.url).searchParams.get("action") || "";
  const body = req.method === "POST" ? await parseBody(req) : {};
  action = body.action || action || (req.method === "GET" ? "me" : "");

  try {
    if (action === "login") return login(req, body);
    if (action === "logout") return logout(req);
    if (action === "logout-all") return logoutAll(req);
    if (action === "me") return me(req);
    if (action === "change-password") return changePassword(req, body);
    if (action === "verify") return verify(req, body);
    if (action === "forgot") return forgot(req, body);
    if (action === "reset") return reset(req, body);
    if (action === "provision") return provision(req, body);
    if (action === "claim") return claim(req, body);
    if (action === "deactivate") return deactivate(req, body);
    if (action === "set-role") return setRole(req, body);
    if (action === "sessions") return listSessions(req);
    if (action === "issue-reset") return issueReset(req, body);
    return jsonRes(req, { error: "Unknown action" }, 400);
  } catch (err) {
    return jsonRes(req, { error: String(err.message || err) }, 500);
  }
}

async function login(req, body) {
  const username = String(body.username || body.user || "").trim().toLowerCase();
  const password = String(body.password || body.pin || "");
  if (!username || !password) return jsonRes(req, { error: "Username and password required" }, 400);
  const blocked = await checkAttempts(username);
  if (blocked) return jsonRes(req, { error: blocked }, 429);
  await ensureDemoUsers();
  const users = await loadUsers();
  const user = users[username];
  if (!user || user.pending || !user.passwordHash) {
    await recordAttempt(username, false);
    return jsonRes(req, { error: "Invalid username or password" }, 401);
  }
  if (user.active === false) return jsonRes(req, { error: "Account disabled" }, 403);
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    await recordAttempt(username, false);
    return jsonRes(req, { error: "Invalid username or password" }, 401);
  }
  await recordAttempt(username, true);
  user.lastLoginAt = Date.now();
  users[username] = user;
  await saveUsers(users);
  const sess = await createSession(user, !!body.rememberMe, body.deviceName || req.headers.get("user-agent") || "device");
  return jsonRes(req, { user: publicUser(user), sessionId: sess.session.id }, 200, {
    "set-cookie": cookieHeader(sess.cookie, sess.maxAge),
  });
}

async function logout(req) {
  const auth = await readSession(req);
  if (auth?.session) await revokeSession(auth.session.id);
  return jsonRes(req, { ok: true }, 200, { "set-cookie": cookieHeader("", 0) });
}

async function logoutAll(req) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  await revokeUserSessions(auth.user.user);
  return jsonRes(req, { ok: true }, 200, { "set-cookie": cookieHeader("", 0) });
}

async function me(req) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { user: null }, 200);
  return jsonRes(req, { user: publicUser(auth.user), sessionId: auth.session.id });
}

async function changePassword(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  const current = String(body.current || "");
  const next = String(body.next || body.password || "");
  if (next.length < 4) return jsonRes(req, { error: "New password must be at least 4 characters" }, 400);
  if (!(await verifyPassword(current, auth.user.passwordHash))) return jsonRes(req, { error: "Current password is wrong" }, 403);
  const users = await loadUsers();
  users[auth.user.user] = { ...users[auth.user.user], passwordHash: await hashPassword(next) };
  await saveUsers(users);
  await revokeUserSessions(auth.user.user, auth.session.id);
  return jsonRes(req, { ok: true });
}

async function verify(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  const password = String(body.password || body.pin || "");
  const ok = await verifyPassword(password, auth.user.passwordHash);
  if (!ok) return jsonRes(req, { error: "Wrong password" }, 403);
  return jsonRes(req, { ok: true, user: publicUser(auth.user) });
}

async function forgot(req, body) {
  const username = String(body.username || body.user || "").trim().toLowerCase();
  const users = await loadUsers();
  const user = users[username];
  const echo = process.env.AUTH_RESET_ECHO === "true";
  if (!user) return jsonRes(req, { ok: true, hint: "If that account exists, an admin can issue a reset." });
  const token = newId() + newId();
  const resets = (await blobGet(RESETS_KEY)) || {};
  resets[sha256(token)] = { user: user.user, expiresAt: Date.now() + 30 * 60 * 1000, used: false };
  await blobPut(RESETS_KEY, resets);
  return jsonRes(req, {
    ok: true,
    hint: echo ? "Demo echo is on — token returned once." : "Ask an admin for a reset, or configure email (RESEND_API_KEY).",
    resetToken: echo ? token : undefined,
  });
}

async function reset(req, body) {
  const token = String(body.token || "");
  const next = String(body.password || body.pin || "");
  if (!token || next.length < 4) return jsonRes(req, { error: "Token and new password required" }, 400);
  const resets = (await blobGet(RESETS_KEY)) || {};
  const row = resets[sha256(token)];
  if (!row || row.used || row.expiresAt < Date.now()) return jsonRes(req, { error: "Reset link expired" }, 400);
  const users = await loadUsers();
  if (!users[row.user]) return jsonRes(req, { error: "Account missing" }, 400);
  users[row.user] = { ...users[row.user], passwordHash: await hashPassword(next), pending: false, active: true };
  row.used = true;
  await saveUsers(users);
  await blobPut(RESETS_KEY, resets);
  await revokeUserSessions(row.user);
  return jsonRes(req, { ok: true });
}

async function provision(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  if (auth.user.role !== "admin") return jsonRes(req, { error: "Admin only" }, 403);
  const name = String(body.name || "").trim();
  const role = String(body.role || "tech");
  if (!name) return jsonRes(req, { error: "Name required" }, 400);
  const staffKey = String(body.staffKey || "staff-" + newId().slice(0, 10)).toLowerCase();
  const users = await loadUsers();
  users[staffKey] = {
    user: staffKey,
    name,
    role,
    email: String(body.email || ""),
    passwordHash: "",
    active: true,
    pending: true,
    createdAt: Date.now(),
    lastLoginAt: 0,
  };
  await saveUsers(users);
  return jsonRes(req, { ok: true, staffKey });
}

async function claim(req, body) {
  const staffKey = String(body.staffKey || "").trim().toLowerCase();
  const username = String(body.username || body.user || "").trim().toLowerCase().replace(/\s+/g, "");
  const password = String(body.password || body.pin || "");
  if (!staffKey || !username || password.length < 4) return jsonRes(req, { error: "Username and password required" }, 400);
  const users = await loadUsers();
  const pending = users[staffKey];
  if (!pending || !pending.pending) return jsonRes(req, { error: "This person is already set up" }, 400);
  if (users[username] && username !== staffKey) return jsonRes(req, { error: "Username already exists" }, 400);
  delete users[staffKey];
  users[username] = {
    ...pending,
    user: username,
    passwordHash: await hashPassword(password),
    pending: false,
    active: true,
  };
  await saveUsers(users);
  return jsonRes(req, { ok: true, user: publicUser(users[username]) });
}

async function deactivate(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  if (auth.user.role !== "admin") return jsonRes(req, { error: "Admin only" }, 403);
  const username = String(body.username || body.user || "").trim().toLowerCase();
  const users = await loadUsers();
  if (!users[username]) return jsonRes(req, { error: "Not found" }, 404);
  users[username] = { ...users[username], active: body.active === false ? false : !!body.active };
  if (body.active === false) await revokeUserSessions(username);
  await saveUsers(users);
  return jsonRes(req, { ok: true, user: publicUser(users[username]) });
}

async function setRole(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  if (auth.user.role !== "admin") return jsonRes(req, { error: "Admin only" }, 403);
  const username = String(body.username || body.user || "").trim().toLowerCase();
  const role = String(body.role || "");
  const users = await loadUsers();
  if (!users[username] || !role) return jsonRes(req, { error: "User and role required" }, 400);
  users[username] = { ...users[username], role };
  await saveUsers(users);
  return jsonRes(req, { ok: true, user: publicUser(users[username]) });
}

async function listSessions(req) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  const sessions = await loadSessions();
  const mine = Object.values(sessions)
    .filter((s) => s.user === auth.user.user && !s.revokedAt)
    .map((s) => ({
      id: s.id,
      deviceName: s.deviceName,
      createdAt: s.createdAt,
      lastSeen: s.lastSeen,
      expiresAt: s.expiresAt,
      rememberMe: s.rememberMe,
      current: s.id === auth.session.id,
    }));
  return jsonRes(req, { sessions: mine });
}

async function issueReset(req, body) {
  const auth = await readSession(req);
  if (!auth) return jsonRes(req, { error: "Not signed in" }, 401);
  if (auth.user.role !== "admin") return jsonRes(req, { error: "Admin only" }, 403);
  const username = String(body.username || body.user || "").trim().toLowerCase();
  const users = await loadUsers();
  if (!users[username]) return jsonRes(req, { error: "Not found" }, 404);
  const token = newId() + newId();
  const resets = (await blobGet(RESETS_KEY)) || {};
  resets[sha256(token)] = { user: username, expiresAt: Date.now() + 30 * 60 * 1000, used: false };
  await blobPut(RESETS_KEY, resets);
  return jsonRes(req, { ok: true, resetToken: token, expiresInMinutes: 30 });
}

export const config = { path: "/api/auth" };
