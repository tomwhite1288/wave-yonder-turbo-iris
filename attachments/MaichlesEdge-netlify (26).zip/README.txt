MaichlesEdge Netlify
====================
Same layout as the deploy that published.

Drag this zip onto Deploys (do not unzip).
Asset files are always named:
  assets/app.js
  assets/style.css
so an old hashed copy cannot mix with a new one.

Demo PIN 1234: admin thomas alex devon
