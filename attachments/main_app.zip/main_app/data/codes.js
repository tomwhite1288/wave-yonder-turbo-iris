// Auto-extracted from Code Book sheet
window.DEFAULT_CODES = [
  {
    "code": "WARRANTY",
    "description": "Warranty (No Charge)",
    "listPrice": 0.0,
    "typicalHrs": 2.0,
    "category": "Office",
    "notes": "Repair Is Covered Under Warranty",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "TRUCK-ORG",
    "description": "Truck organize / clean / stock",
    "listPrice": 0.0,
    "typicalHrs": 0.5,
    "category": "Office",
    "notes": "Unapplied Billable Hour",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "SRV-CH",
    "description": "Service Charge",
    "listPrice": 120.0,
    "typicalHrs": 1.0,
    "category": "Office",
    "notes": "Rate Price For Coming Out (no contract)",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PR1C",
    "description": "Jetting Lines Up to 2HR",
    "listPrice": 1054.0,
    "typicalHrs": 2.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PR1A",
    "description": "Jetting Lines Additional hour(s)",
    "listPrice": 200.0,
    "typicalHrs": 1.0,
    "category": "Drain-Cleaning",
    "notes": "Additional Hours After The First Two",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PM9C",
    "description": "Generic Task materials up to $600 / ~2.0 hr",
    "listPrice": 1402.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1002",
    "active": "Y",
    "partsCost": 600.0
  },
  {
    "code": "PM9B",
    "description": "Generic Task materials up to $600 / ~1.5 hr",
    "listPrice": 1302.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1002",
    "active": "Y",
    "partsCost": 600.0
  },
  {
    "code": "PM9A",
    "description": "Generic Task materials up to $600 / ~1.0 hr",
    "listPrice": 1202.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1002",
    "active": "Y",
    "partsCost": 600.0
  },
  {
    "code": "PM8C",
    "description": "Generic Task materials up to $500 / ~2.0 hr",
    "listPrice": 1235.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$835",
    "active": "Y",
    "partsCost": 500.0
  },
  {
    "code": "PM8B",
    "description": "Generic Task materials up to $500 / ~1.5 hr",
    "listPrice": 1135.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$835",
    "active": "Y",
    "partsCost": 500.0
  },
  {
    "code": "PM8A",
    "description": "Generic Task materials up to $500 / ~1.0 hr",
    "listPrice": 1035.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$835",
    "active": "Y",
    "partsCost": 500.0
  },
  {
    "code": "PM7C",
    "description": "Generic Task materials up to $400 / ~2.0 hr",
    "listPrice": 1068.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$668",
    "active": "Y",
    "partsCost": 400.0
  },
  {
    "code": "PM7B",
    "description": "Generic Task materials up to $400 / ~1.5 hr",
    "listPrice": 968.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$668",
    "active": "Y",
    "partsCost": 400.0
  },
  {
    "code": "PM7A",
    "description": "Generic Task materials up to $400 / ~1.0 hr",
    "listPrice": 868.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$668",
    "active": "Y",
    "partsCost": 400.0
  },
  {
    "code": "PM6C",
    "description": "Generic Task materials up to $300 / ~2.0 hr",
    "listPrice": 900.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$500",
    "active": "Y",
    "partsCost": 300.0
  },
  {
    "code": "PM6B",
    "description": "Generic Task materials up to $300 / ~1.5 hr",
    "listPrice": 800.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$500",
    "active": "Y",
    "partsCost": 300.0
  },
  {
    "code": "PM6A",
    "description": "PM tier6 / ~1 hr",
    "listPrice": 700.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 300.0
  },
  {
    "code": "PM5C",
    "description": "Generic Task materials up to $200 / ~2.0 hr",
    "listPrice": 734.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$334",
    "active": "Y",
    "partsCost": 200.0
  },
  {
    "code": "PM5B",
    "description": "Generic Task materials up to $200 / ~1.5 hr",
    "listPrice": 634.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$334",
    "active": "Y",
    "partsCost": 200.0
  },
  {
    "code": "PM5A",
    "description": "PM tier5 / ~1 hr",
    "listPrice": 534.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 200.0
  },
  {
    "code": "PM4C",
    "description": "PM tier4 / ~2 hr",
    "listPrice": 567.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 100.0
  },
  {
    "code": "PM4B",
    "description": "PM tier4 / ~1.5 hr",
    "listPrice": 467.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 100.0
  },
  {
    "code": "PM4A",
    "description": "PM tier4 / ~1 hr",
    "listPrice": 367.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 100.0
  },
  {
    "code": "PM3C",
    "description": "Generic Task materials up to $75 / ~2.0 hr",
    "listPrice": 525.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$125",
    "active": "Y",
    "partsCost": 75.0
  },
  {
    "code": "PM3B",
    "description": "Generic Task materials up to $75 / ~1.5 hr",
    "listPrice": 425.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 75.0
  },
  {
    "code": "PM3A",
    "description": "Generic Task materials up to $75 / ~1.0 hr",
    "listPrice": 325.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$125",
    "active": "Y",
    "partsCost": 75.0
  },
  {
    "code": "PM2C",
    "description": "PM tier2 / ~2 hr",
    "listPrice": 484.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 50.0
  },
  {
    "code": "PM2B",
    "description": "PM tier2 / ~1.5 hr",
    "listPrice": 384.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 50.0
  },
  {
    "code": "PM2A",
    "description": "PM tier2 / ~1 hr",
    "listPrice": 284.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 50.0
  },
  {
    "code": "PM1C",
    "description": "PM tier1 / ~2 hr",
    "listPrice": 442.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 25.0
  },
  {
    "code": "PM1B",
    "description": "PM tier1 / ~1.5 hr",
    "listPrice": 342.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 25.0
  },
  {
    "code": "PM1A",
    "description": "PM tier1 / ~1 hr",
    "listPrice": 242.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "",
    "active": "Y",
    "partsCost": 25.0
  },
  {
    "code": "PM13C",
    "description": "Generic Task materials up to $1000 / ~2.0 hr",
    "listPrice": 2070.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1670",
    "active": "Y",
    "partsCost": 1000.0
  },
  {
    "code": "PM13B",
    "description": "Generic Task materials up to $1000 / ~1.5 hr",
    "listPrice": 1970.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1670",
    "active": "Y",
    "partsCost": 1000.0
  },
  {
    "code": "PM13A",
    "description": "Generic Task materials up to $1000 / ~1.0 hr",
    "listPrice": 1870.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1670",
    "active": "Y",
    "partsCost": 1000.0
  },
  {
    "code": "PM12C",
    "description": "Generic Task materials up to $900 / ~2.0 hr",
    "listPrice": 1903.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1503",
    "active": "Y",
    "partsCost": 900.0
  },
  {
    "code": "PM12B",
    "description": "Generic Task materials up to $900 / ~1.5 hr",
    "listPrice": 1803.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1503",
    "active": "Y",
    "partsCost": 900.0
  },
  {
    "code": "PM12A",
    "description": "Generic Task materials up to $900 / ~1.0 hr",
    "listPrice": 1703.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1503",
    "active": "Y",
    "partsCost": 900.0
  },
  {
    "code": "PM11C",
    "description": "Generic Task materials up to $800 / ~2.0 hr",
    "listPrice": 1736.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1336",
    "active": "Y",
    "partsCost": 800.0
  },
  {
    "code": "PM11B",
    "description": "Generic Task materials up to $800 / ~1.5 hr",
    "listPrice": 1636.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1336",
    "active": "Y",
    "partsCost": 800.0
  },
  {
    "code": "PM11A",
    "description": "Generic Task materials up to $800 / ~1.0 hr",
    "listPrice": 1536.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1336",
    "active": "Y",
    "partsCost": 800.0
  },
  {
    "code": "PM10C",
    "description": "Generic Task materials up to $700 / ~2.0 hr",
    "listPrice": 1569.0,
    "typicalHrs": 2.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1169",
    "active": "Y",
    "partsCost": 700.0
  },
  {
    "code": "PM10B",
    "description": "Generic Task materials up to $700 / ~1.5 hr",
    "listPrice": 1469.0,
    "typicalHrs": 1.5,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1169",
    "active": "Y",
    "partsCost": 700.0
  },
  {
    "code": "PM10A",
    "description": "Generic Task materials up to $700 / ~1.0 hr",
    "listPrice": 1369.0,
    "typicalHrs": 1.0,
    "category": "Price/Labor & Material",
    "notes": "Mat sell ~$1169",
    "active": "Y",
    "partsCost": 700.0
  },
  {
    "code": "PH3B",
    "description": "Ice Maker Water Line",
    "listPrice": 517.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PH2A",
    "description": "Hose Bibs (8\"-10\")",
    "listPrice": 310.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PH1A",
    "description": "Customer Supplied - Hose Bib",
    "listPrice": 285.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PG3B",
    "description": "Disposal",
    "listPrice": 517.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PG2B",
    "description": "Kitchen Faucet",
    "listPrice": 578.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PG1B",
    "description": "H.O.Supplied Kitchen Faucet INSTALL",
    "listPrice": 385.0,
    "typicalHrs": 2.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PF5B",
    "description": "Vanity Faucet",
    "listPrice": 521.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PF4B",
    "description": "Install (HO Supplied) Levy/Vanity Faucet",
    "listPrice": 384.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PF1B",
    "description": "Tub / Shower Mixer Valve - Repair",
    "listPrice": 687.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE7B-50",
    "description": "Electric 50 gallon",
    "listPrice": 2327.0,
    "typicalHrs": 4.0,
    "category": "Install",
    "notes": "M/A=1978 (alt PE7B)",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE7B",
    "description": "Electric 40 gallon",
    "listPrice": 2492.0,
    "typicalHrs": 4.0,
    "category": "Install",
    "notes": "M/A=2118",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE5B",
    "description": "Gas 75 gallon",
    "listPrice": 3288.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "M/A=2795",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE3B",
    "description": "Gas 50 gallon",
    "listPrice": 3086.0,
    "typicalHrs": 4.0,
    "category": "Install",
    "notes": "M/A=2624",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE2B",
    "description": "Gas 40 gallon",
    "listPrice": 2706.0,
    "typicalHrs": 4.0,
    "category": "Install",
    "notes": "M/A=2301",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE18A",
    "description": "75 gallon Powervent",
    "listPrice": 6852.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "M/A=5825",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE17A",
    "description": "50 gallon Powervent",
    "listPrice": 5045.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "M/A=4289",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE16B",
    "description": "40 Gallon NG PowerVenter HWH Install",
    "listPrice": 3699.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE11A",
    "description": "Tankless",
    "listPrice": 5405.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "M/A=4595",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PE10B",
    "description": "Electric 80 gallon",
    "listPrice": 4133.0,
    "typicalHrs": 5.0,
    "category": "Install",
    "notes": "M/A=3514",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PD8E",
    "description": "Sump Pump W Battery Back-up",
    "listPrice": 2498.0,
    "typicalHrs": 3.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PD7E",
    "description": "Sump Pump W/ Waterpower Back-up Option",
    "listPrice": 1884.0,
    "typicalHrs": 3.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PD3B",
    "description": "Sump Pump",
    "listPrice": 765.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC9B",
    "description": "Customer Supplied - Standard Toilet",
    "listPrice": 350.0,
    "typicalHrs": 1.5,
    "category": "Install",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC9A",
    "description": "Flange Replacement",
    "listPrice": 620.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC1A",
    "description": "Basic Repair Section Toilet (Float/Flapper/Lever/Fill Valve)",
    "listPrice": 308.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC12A",
    "description": "Commercial Repair - Section Toilet/Urinal",
    "listPrice": 568.0,
    "typicalHrs": 1.5,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC10B",
    "description": "Replacement Toilet - Standard",
    "listPrice": 750.0,
    "typicalHrs": 1.5,
    "category": "Install",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PC10A",
    "description": "Flange repair",
    "listPrice": 963.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PB4A",
    "description": "Expansion Tank",
    "listPrice": 447.0,
    "typicalHrs": 1.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PB1C",
    "description": "Pressure Regulator Valve",
    "listPrice": 714.0,
    "typicalHrs": 2.0,
    "category": "Plumbing",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PA7C",
    "description": "Sewer Camera up to 2hrs",
    "listPrice": 549.0,
    "typicalHrs": 2.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PA7A",
    "description": "Camera additional hour(s)",
    "listPrice": 180.0,
    "typicalHrs": 1.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PA6A",
    "description": "Drain Machine Additional Hour(s)",
    "listPrice": 120.0,
    "typicalHrs": 1.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PA5B",
    "description": "Main Line Drain Cleaning Without Clean Out Access",
    "listPrice": 979.0,
    "typicalHrs": 2.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "PA1A",
    "description": "Interior branch line cable",
    "listPrice": 273.0,
    "typicalHrs": 2.0,
    "category": "Drain-Cleaning",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "MULTI",
    "description": "",
    "listPrice": 0.0,
    "typicalHrs": null,
    "category": "",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "MANUAL",
    "description": "Manual parts & labor \u2014 type $ and hours on log",
    "listPrice": 0.0,
    "typicalHrs": null,
    "category": "Manual",
    "notes": "Type Final $, Hours, Parts Manually",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "EST",
    "description": "Estimate",
    "listPrice": 0.0,
    "typicalHrs": 0.5,
    "category": "Office",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "DIAG",
    "description": "Diagnostic Fee",
    "listPrice": 59.0,
    "typicalHrs": 1.0,
    "category": "Office",
    "notes": "",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "CALLBACK",
    "description": "Callback / rework \u2014 no charge",
    "listPrice": 0.0,
    "typicalHrs": 1.0,
    "category": "Office",
    "notes": "Bill office, not customer",
    "active": "Y",
    "partsCost": null
  },
  {
    "code": "14",
    "description": "Shop / Unapplied Billable Hours",
    "listPrice": 0.0,
    "typicalHrs": null,
    "category": "Shop",
    "notes": "",
    "active": "Y",
    "partsCost": null
  }
];
