(function () {
  'use strict';

  const KEYS = {
    pin: 'tt_pin', recovery: 'tt_recovery', codes: 'tt_codes', jobs: 'tt_jobs',
    shop: 'tt_shop', settings: 'tt_settings', techs: 'tt_techs',
    activeTech: 'tt_active_tech', unlocked: 'tt_unlocked', draft: 'tt_draft'
  };

  const DEFAULT_SETTINGS = {
    laborRate: 200, wage: 29, markup: 68,
    maxPreferredDisc: 15, maxDiscDollars: 200, availHrsWeek: 30
  };
  const DEFAULT_PIN = '1234';
  const DEFAULT_RECOVERY = 'RESET';
  const DEFAULT_TECHS = ['Thomas White', 'Tech 1'];
  const STATUSES = ['draft', 'assigned', 'working', 'completed'];

  let codes = [], jobs = [], shopTime = [], settings = { ...DEFAULT_SETTINGS };
  let techs = [...DEFAULT_TECHS], activeTech = 'Thomas White';
  let draft = null, editingCodeIndex = -1, pinAttempts = 0, previewCode = null;
  let lastHomeSnap = null;

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);

  function toast(msg, type = '') {
    const el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.hidden = true; }, 2500);
  }
  function money(n) {
    return '$' + (Number(n) || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  function todayISO() { return new Date().toISOString().slice(0, 10); }
  function loadJSON(k, fb) {
    try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : fb; } catch { return fb; }
  }
  function saveJSON(k, v) { localStorage.setItem(k, JSON.stringify(v)); }

  function getPin() { return localStorage.getItem(KEYS.pin) || DEFAULT_PIN; }
  function getRecovery() { return (localStorage.getItem(KEYS.recovery) || DEFAULT_RECOVERY).toUpperCase(); }

  function unlock() {
    sessionStorage.setItem(KEYS.unlocked, '1');
    pinAttempts = 0;
    $('#login-screen').classList.remove('active');
    $('#app').classList.add('active');
    initApp();
    switchTab('home');
  }
  function lock() {
    sessionStorage.removeItem(KEYS.unlocked);
    $('#app').classList.remove('active');
    $('#login-screen').classList.add('active');
    $('#pin').value = '';
    $('#forgot-panel').hidden = true;
    $('#btn-forgot-pin').hidden = true;
    pinAttempts = 0;
  }

  function loadData() {
    codes = loadJSON(KEYS.codes, null);
    if (!codes || !codes.length) {
      codes = (window.DEFAULT_CODES || []).map(c => ({ ...c }));
      saveJSON(KEYS.codes, codes);
    }
    jobs = loadJSON(KEYS.jobs, []);
    shopTime = loadJSON(KEYS.shop, []);
    settings = { ...DEFAULT_SETTINGS, ...loadJSON(KEYS.settings, {}) };
    techs = loadJSON(KEYS.techs, null);
    if (!techs || !techs.length) { techs = [...DEFAULT_TECHS]; saveJSON(KEYS.techs, techs); }
    activeTech = localStorage.getItem(KEYS.activeTech) || techs[0];
    draft = loadJSON(KEYS.draft, null);
    if (!draft) resetDraft();
  }

  function resetDraft(seedCode) {
    draft = {
      id: null,
      ref: '',
      status: 'draft',
      notes: '',
      assignedTo: activeTech,
      preferredPct: 0,
      lines: [],
      date: todayISO()
    };
    if (seedCode) {
      draft.lines.push({
        code: seedCode.code,
        list: seedCode.listPrice || 0,
        hrs: seedCode.typicalHrs || 0,
        parts: seedCode.partsCost || 0
      });
    }
    saveJSON(KEYS.draft, draft);
  }

  // ─── Pricing ──────────────────────────────────────────────
  function computeTotals(lines, preferredPct) {
    let subtotal = 0, hrs = 0, parts = 0;
    lines.forEach(l => {
      subtotal += Number(l.list) || 0;
      hrs += Number(l.hrs) || 0;
      parts += Number(l.parts) || 0;
    });
    let disc = subtotal * ((Number(preferredPct) || 0) / 100);
    const cap = settings.maxDiscDollars || 200;
    let capped = false;
    if (disc > cap) { disc = cap; capped = true; }
    const total = Math.max(0, subtotal - disc);
    return { subtotal, disc, total, hrs, parts, capped };
  }

  // ─── Smart finder ─────────────────────────────────────────
  const PARTS_TIERS = [25, 50, 75, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
  function findBestPMCodes(hours, partsCost) {
    const h = Number(hours) || 0, p = Number(partsCost) || 0;
    let bestTier = PARTS_TIERS[0], bestDiff = Math.abs(p - bestTier);
    for (const t of PARTS_TIERS) {
      const d = Math.abs(p - t);
      if (d < bestDiff) { bestDiff = d; bestTier = t; }
    }
    let letter = 'A';
    if (h >= 1.75) letter = 'C';
    else if (h >= 1.25) letter = 'B';
    const map = { 25:1,50:2,75:3,100:4,200:5,300:6,400:7,500:8,600:9,700:10,800:11,900:12,1000:13 };
    const primaryCode = `PM${map[bestTier] || 2}${letter}`;
    const candidates = codes.filter(c =>
      c.code.startsWith('PM') && c.partsCost != null && Math.abs((c.partsCost || 0) - p) <= 150
    );
    candidates.forEach(c => {
      c._score = Math.abs((c.typicalHrs || 0) - h) + Math.abs((c.partsCost || 0) - p) / 50;
    });
    candidates.sort((a, b) => a._score - b._score);
    const primary = codes.find(c => c.code === primaryCode);
    const out = [];
    if (primary) out.push(primary);
    for (const c of candidates) if (c.code !== primaryCode && out.length < 5) out.push(c);
    return out;
  }

  // ─── Period helper ────────────────────────────────────────
  function getPeriodRange(period) {
    const now = new Date();
    const sod = (d) => { const x = new Date(d); x.setHours(0,0,0,0); return x; };
    const eod = (d) => { const x = new Date(d); x.setHours(23,59,59,999); return x; };
    let from, to = eod(now);
    if (period === 'thisWeek') {
      const day = now.getDay(), diff = day === 0 ? 6 : day - 1;
      from = sod(now); from.setDate(from.getDate() - diff);
    } else if (period === 'lastWeek') {
      const day = now.getDay(), diff = day === 0 ? 6 : day - 1;
      to = eod(now); to.setDate(to.getDate() - diff - 1);
      from = sod(to); from.setDate(from.getDate() - 6);
    } else if (period === 'last7') {
      from = sod(now); from.setDate(from.getDate() - 6);
    } else if (period === 'thisMonth') {
      from = sod(new Date(now.getFullYear(), now.getMonth(), 1));
    } else {
      from = new Date(0); to = new Date(8640000000000000);
    }
    return { from, to };
  }

  // ─── Render: Job form ─────────────────────────────────────
  function loadDraftToForm() {
    if (!draft) resetDraft();
    $('#job-ref').value = draft.ref || '';
    $('#job-status').value = draft.status || 'draft';
    $('#job-notes').value = draft.notes || '';
    $('#job-pref').value = String(draft.preferredPct || 0);
    const badge = $('#job-status-badge');
    badge.textContent = draft.status || 'draft';
    badge.className = 'status-badge ' + (draft.status || 'draft');
    $('#job-heading').textContent = draft.id ? 'Edit job' : 'New job';
    renderAssignSelect();
    $('#job-assign').value = draft.assignedTo || activeTech;
    renderJobLines();
  }

  function formToDraft() {
    draft.ref = ($('#job-ref').value || '').trim();
    draft.status = $('#job-status').value || 'draft';
    draft.notes = ($('#job-notes').value || '').trim();
    draft.preferredPct = Number($('#job-pref').value) || 0;
    draft.assignedTo = $('#job-assign').value || activeTech;
    saveJSON(KEYS.draft, draft);
  }

  function renderJobLines() {
    const box = $('#job-lines');
    box.innerHTML = '';
    if (!draft.lines.length) {
      box.innerHTML = '<p class="hint">No lines — add from Price book or + Code</p>';
    } else {
      draft.lines.forEach((l, i) => {
        const el = document.createElement('div');
        el.className = 'inv-line';
        el.innerHTML = `
          <div class="info"><div class="code">${l.code}</div>
          <div class="meta">${l.hrs || 0}h · parts ${money(l.parts || 0)}</div></div>
          <div class="amt">${money(l.list || 0)}</div>
          <button type="button" class="rm" data-i="${i}">✕</button>`;
        el.querySelector('.rm').addEventListener('click', () => {
          draft.lines.splice(i, 1);
          saveJSON(KEYS.draft, draft);
          renderJobLines();
        });
        box.appendChild(el);
      });
    }
    const t = computeTotals(draft.lines, draft.preferredPct || Number($('#job-pref').value) || 0);
    $('#job-subtotal').textContent = money(t.subtotal);
    $('#job-discount').textContent = money(t.disc);
    $('#job-total').textContent = money(t.total);
    $('#job-hrs').textContent = t.hrs.toFixed(2);
    $('#job-cap-note').hidden = !t.capped;
  }

  function saveJob() {
    formToDraft();
    if (!draft.ref) { toast('Ref / Invoice # required', 'error'); return; }
    if (!draft.lines.length) { toast('Add at least one line', 'error'); return; }
    const t = computeTotals(draft.lines, draft.preferredPct);
    const job = {
      id: draft.id || Date.now().toString(36),
      ref: draft.ref,
      status: draft.status,
      notes: draft.notes,
      assignedTo: draft.assignedTo,
      preferredPct: draft.preferredPct,
      lines: draft.lines.map(l => ({ ...l })),
      subtotal: t.subtotal,
      discount: t.disc,
      total: t.total,
      hrs: t.hrs,
      parts: t.parts,
      date: draft.date || todayISO(),
      updatedAt: new Date().toISOString(),
      createdBy: activeTech
    };
    const idx = jobs.findIndex(j => j.id === job.id);
    if (idx >= 0) jobs[idx] = job;
    else jobs.unshift(job);
    saveJSON(KEYS.jobs, jobs);
    resetDraft();
    loadDraftToForm();
    renderHome();
    renderLog();
    toast('Job saved', 'success');
  }

  function openJob(job) {
    draft = {
      id: job.id,
      ref: job.ref,
      status: job.status,
      notes: job.notes || '',
      assignedTo: job.assignedTo || activeTech,
      preferredPct: job.preferredPct || 0,
      lines: (job.lines || []).map(l => ({ ...l })),
      date: job.date
    };
    saveJSON(KEYS.draft, draft);
    loadDraftToForm();
    switchTab('job');
  }

  // ─── Price book ───────────────────────────────────────────
  function renderCodeList(q = '', cat = '') {
    q = q.trim().toLowerCase();
    const list = $('#code-list');
    list.innerHTML = '';
    const filtered = codes.filter(c => {
      if (c.active === 'N') return false;
      if (cat && c.category !== cat) return false;
      if (!q) return true;
      return [c.code, c.description, c.notes, c.category].some(x =>
        (x || '').toLowerCase().includes(q)
      );
    });
    filtered.sort((a, b) => a.code.localeCompare(b.code));
    if (!filtered.length) {
      list.innerHTML = '<p class="hint" style="text-align:center;padding:16px">No matches</p>';
      return;
    }
    filtered.forEach(c => {
      const el = document.createElement('div');
      el.className = 'code-item';
      el.innerHTML = `
        <div class="left">
          <div class="code">${c.code}</div>
          <div class="desc">${c.description || '—'}</div>
          <div class="meta">${c.category || ''}${c.partsCost != null ? ' · parts ~$' + c.partsCost : ''}</div>
        </div>
        <div class="right">
          <div class="price">${money(c.listPrice)}</div>
          <div class="meta">${c.typicalHrs != null ? c.typicalHrs + 'h' : ''}</div>
        </div>`;
      el.addEventListener('click', () => showCodePreview(c));
      list.appendChild(el);
    });
  }

  function showCodePreview(c) {
    previewCode = c;
    $('#preview-title').textContent = c.code;
    $('#preview-body').innerHTML = `
      <p><strong>${c.description || ''}</strong></p>
      <div class="breakdown">
        <div><span>List price</span><span>${money(c.listPrice)}</span></div>
        <div><span>Typical hours</span><span>${c.typicalHrs != null ? c.typicalHrs : '—'}</span></div>
        <div><span>Parts cost</span><span>${c.partsCost != null ? money(c.partsCost) : '—'}</span></div>
        <div><span>Category</span><span>${c.category || '—'}</span></div>
      </div>
      ${c.notes ? '<p class="hint">' + c.notes + '</p>' : ''}`;
    $('#preview-modal').hidden = false;
  }

  function addCodeToDraft(c) {
    if (!draft) resetDraft();
    draft.lines.push({
      code: c.code,
      list: c.listPrice || 0,
      hrs: c.typicalHrs || 0,
      parts: c.partsCost || 0
    });
    saveJSON(KEYS.draft, draft);
    toast(c.code + ' added to job', 'success');
  }

  function populateCategories() {
    const cats = [...new Set(codes.map(c => c.category).filter(Boolean))].sort();
    const sel = $('#filter-category');
    sel.innerHTML = '<option value="">All categories</option>';
    cats.forEach(cat => {
      const o = document.createElement('option');
      o.value = cat; o.textContent = cat;
      sel.appendChild(o);
    });
  }

  function populateDatalist() {
    const dl = $('#code-datalist');
    dl.innerHTML = '';
    codes.filter(c => c.active !== 'N').forEach(c => {
      const o = document.createElement('option');
      o.value = c.code; o.label = c.description || c.code;
      dl.appendChild(o);
    });
  }

  // ─── Home ─────────────────────────────────────────────────
  function renderHome() {
    $('#home-tech-name').textContent = activeTech;
    $('#home-greeting').textContent = new Date().toLocaleDateString(undefined, {
      weekday: 'long', month: 'short', day: 'numeric'
    });

    const period = $('#home-period').value;
    const { from, to } = getPeriodRange(period);
    const mine = (j) => !j.assignedTo || j.assignedTo === activeTech;
    const inPeriod = jobs.filter(j => {
      const d = new Date((j.date || '') + 'T12:00:00');
      return d >= from && d <= to && mine(j);
    });
    const open = jobs.filter(j => mine(j) && j.status !== 'completed');
    const revenue = inPeriod.reduce((s, j) => s + (j.total || 0), 0);
    const billHrs = inPeriod.reduce((s, j) => s + (j.hrs || 0), 0);
    const shopHrs = shopTime.filter(s => {
      const d = new Date((s.date || '') + 'T12:00:00');
      return d >= from && d <= to && (!s.tech || s.tech === activeTech);
    }).reduce((s, x) => s + (x.hrs || 0), 0);
    const avail = settings.availHrsWeek || 30;
    const eff = billHrs > 0 && avail > 0 ? billHrs / avail : 0;

    lastHomeSnap = { period, open, inPeriod, revenue, billHrs, shopHrs, avail, eff, tech: activeTech };

    $('#home-open').textContent = open.length;
    $('#home-revenue').textContent = money(revenue);
    $('#home-hrs').textContent = billHrs.toFixed(1);
    $('#home-eff').textContent = (eff * 100).toFixed(0) + '%';

    const list = $('#home-open-list');
    list.innerHTML = '';
    if (!open.length) {
      list.innerHTML = '<p class="hint">No open jobs — tap New job to start</p>';
    } else {
      open.slice(0, 12).forEach(j => list.appendChild(jobCard(j)));
    }
  }

  function jobCard(j) {
    const el = document.createElement('div');
    el.className = 'job-card';
    el.innerHTML = `
      <div class="top">
        <div>
          <div class="ref">${j.ref} <span class="status-badge ${j.status}">${j.status}</span></div>
          <div class="meta">${j.date || ''} · ${(j.lines || []).length} line(s) · ${j.assignedTo || ''}</div>
        </div>
        <div style="font-weight:700">${money(j.total)}</div>
      </div>`;
    el.addEventListener('click', () => openJob(j));
    return el;
  }

  function showMetric(metric) {
    if (!lastHomeSnap) renderHome();
    const s = lastHomeSnap;
    const titles = { open: 'Open jobs', revenue: 'Revenue', hrs: 'Billable hours', eff: 'Efficiency' };
    $('#metric-title').textContent = titles[metric] || metric;
    let html = `<p><strong>Tech:</strong> ${s.tech}<br><strong>Period:</strong> ${s.period}</p>`;
    if (metric === 'open') {
      html += `<div class="formula">Jobs assigned to you that are not Completed.

Count: ${s.open.length}</div>`;
      if (s.open.length) {
        html += '<div class="breakdown">';
        s.open.slice(0, 10).forEach(j => {
          html += `<div><span>${j.ref} · ${j.status}</span><span>${money(j.total)}</span></div>`;
        });
        html += '</div>';
      }
    } else if (metric === 'revenue') {
      html += `<div class="formula">Sum of job totals in the selected period
for this technician.

${money(s.revenue)}</div>`;
    } else if (metric === 'hrs') {
      html += `<div class="formula">Sum of billable hours on jobs in period.

Billable: ${s.billHrs.toFixed(2)}
Shop time (same period): ${s.shopHrs.toFixed(2)}</div>`;
    } else if (metric === 'eff') {
      html += `<div class="formula">Efficiency = Billable hrs ÷ Available hrs/week

${s.billHrs.toFixed(2)} ÷ ${s.avail} = ${(s.eff * 100).toFixed(1)}%

Available hrs is set under More → Rates.</div>`;
    }
    $('#metric-body').innerHTML = html;
    $('#metric-modal').hidden = false;
  }

  // ─── Log ──────────────────────────────────────────────────
  function renderLog() {
    const status = $('#log-status').value;
    const period = $('#log-period').value;
    const { from, to } = getPeriodRange(period);
    let rows = jobs.filter(j => {
      const d = new Date((j.date || '') + 'T12:00:00');
      const dateOk = d >= from && d <= to;
      const techOk = !j.assignedTo || j.assignedTo === activeTech;
      const statusOk = !status || j.status === status;
      return dateOk && techOk && statusOk;
    });
    const list = $('#log-list');
    list.innerHTML = '';
    if (!rows.length) list.innerHTML = '<p class="hint">No jobs match filters</p>';
    else rows.forEach(j => list.appendChild(jobCard(j)));

    const shopList = $('#shop-list');
    shopList.innerHTML = '';
    const shopRows = shopTime.filter(s => !s.tech || s.tech === activeTech).slice(0, 15);
    if (!shopRows.length) shopList.innerHTML = '<p class="hint">No shop time logged</p>';
    else shopRows.forEach(s => {
      const div = document.createElement('div');
      div.innerHTML = `<span>${s.date} · ${s.hrs}h</span><span>${s.note || ''}</span>`;
      shopList.appendChild(div);
    });
  }

  function saveShopTime() {
    const hrs = Number($('#shop-hrs').value) || 0;
    if (hrs <= 0) { toast('Enter hours', 'error'); return; }
    shopTime.unshift({
      id: Date.now().toString(36),
      date: todayISO(),
      hrs,
      note: ($('#shop-note').value || '').trim(),
      tech: activeTech
    });
    saveJSON(KEYS.shop, shopTime);
    $('#shop-hrs').value = '';
    $('#shop-note').value = '';
    renderLog();
    renderHome();
    toast('Shop time saved', 'success');
  }

  // ─── Techs / settings ─────────────────────────────────────
  function renderTechSelect() {
    const sel = $('#tech-select');
    sel.innerHTML = '';
    techs.forEach(t => {
      const o = document.createElement('option');
      o.value = t; o.textContent = t;
      if (t === activeTech) o.selected = true;
      sel.appendChild(o);
    });
  }
  function renderAssignSelect() {
    const sel = $('#job-assign');
    if (!sel) return;
    sel.innerHTML = '';
    techs.forEach(t => {
      const o = document.createElement('option');
      o.value = t; o.textContent = t;
      sel.appendChild(o);
    });
  }
  function renderTechList() {
    const list = $('#tech-list');
    list.innerHTML = '';
    techs.forEach((t, i) => {
      const el = document.createElement('div');
      el.className = 'tech-item';
      el.innerHTML = `<span>${t}${t === activeTech ? ' (active)' : ''}</span>
        <button type="button" class="btn small secondary">Remove</button>`;
      el.querySelector('button').addEventListener('click', () => {
        if (techs.length <= 1) { toast('Need at least one', 'error'); return; }
        techs.splice(i, 1);
        if (activeTech === t) activeTech = techs[0];
        saveJSON(KEYS.techs, techs);
        localStorage.setItem(KEYS.activeTech, activeTech);
        renderTechSelect();
        renderTechList();
        renderHome();
        toast('Removed');
      });
      list.appendChild(el);
    });
  }

  function loadSettingsUI() {
    $('#set-labor').value = settings.laborRate;
    $('#set-wage').value = settings.wage;
    $('#set-markup').value = settings.markup;
    $('#set-max-disc').value = settings.maxPreferredDisc;
    $('#set-max-dollars').value = settings.maxDiscDollars;
    $('#set-avail').value = settings.availHrsWeek;
    $('#set-recovery').value = localStorage.getItem(KEYS.recovery) || DEFAULT_RECOVERY;
  }

  function updatePrefOptions() {
    const max = settings.maxPreferredDisc || 15;
    const sel = $('#job-pref');
    const cur = sel.value;
    sel.innerHTML = '<option value="0">None</option>';
    [5, 10, 15, 20, 25].filter(v => v <= max).forEach(v => {
      const o = document.createElement('option');
      o.value = v; o.textContent = v + '%';
      sel.appendChild(o);
    });
    sel.value = cur;
  }

  function renderCodeEditor() {
    const list = $('#code-editor-list');
    list.innerHTML = '';
    codes.forEach((c, i) => {
      const el = document.createElement('div');
      el.className = 'editor-item';
      el.innerHTML = `
        <div class="info">
          <div class="code">${c.code}${c.active === 'N' ? ' (off)' : ''}</div>
          <div class="desc">${c.description || ''} · ${money(c.listPrice || 0)}</div>
        </div>
        <button type="button" class="btn small secondary">Edit</button>`;
      el.querySelector('button').addEventListener('click', () => openCodeModal(i));
      list.appendChild(el);
    });
  }

  function openCodeModal(index) {
    editingCodeIndex = index;
    const c = index >= 0 ? codes[index] : {
      code: '', description: '', listPrice: 0, typicalHrs: 1,
      category: '', notes: '', active: 'Y', partsCost: null
    };
    $('#modal-title').textContent = index >= 0 ? 'Edit code' : 'Add code';
    $('#modal-code').value = c.code;
    $('#modal-code').disabled = index >= 0;
    $('#modal-desc').value = c.description || '';
    $('#modal-price').value = c.listPrice != null ? c.listPrice : '';
    $('#modal-hrs').value = c.typicalHrs != null ? c.typicalHrs : '';
    $('#modal-parts').value = c.partsCost != null ? c.partsCost : '';
    $('#modal-cat').value = c.category || '';
    $('#modal-notes').value = c.notes || '';
    $('#modal-active').checked = c.active !== 'N';
    $('#code-modal').hidden = false;
  }

  function saveCodeModal() {
    const code = ($('#modal-code').value || '').trim().toUpperCase();
    if (!code) { toast('Code required', 'error'); return; }
    const entry = {
      code,
      description: ($('#modal-desc').value || '').trim(),
      listPrice: Number($('#modal-price').value) || 0,
      typicalHrs: $('#modal-hrs').value === '' ? null : Number($('#modal-hrs').value),
      category: ($('#modal-cat').value || '').trim(),
      notes: ($('#modal-notes').value || '').trim(),
      active: $('#modal-active').checked ? 'Y' : 'N',
      partsCost: $('#modal-parts').value === '' ? null : Number($('#modal-parts').value)
    };
    if (editingCodeIndex >= 0) codes[editingCodeIndex] = entry;
    else {
      if (codes.some(c => c.code === code)) { toast('Exists', 'error'); return; }
      codes.push(entry);
    }
    saveJSON(KEYS.codes, codes);
    $('#code-modal').hidden = true;
    renderCodeEditor();
    renderCodeList($('#code-search').value, $('#filter-category').value);
    populateCategories();
    populateDatalist();
    toast('Saved', 'success');
  }

  function exportAll() {
    const blob = new Blob([JSON.stringify({
      codes, jobs, shopTime, settings, techs, exportedAt: new Date().toISOString()
    }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'toolkit-backup.json'; a.click();
    URL.revokeObjectURL(url);
  }

  function importAll(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const d = JSON.parse(reader.result);
        if (d.codes) { codes = d.codes; saveJSON(KEYS.codes, codes); }
        if (d.jobs) { jobs = d.jobs; saveJSON(KEYS.jobs, jobs); }
        if (d.shopTime) { shopTime = d.shopTime; saveJSON(KEYS.shop, shopTime); }
        if (d.settings) { settings = { ...DEFAULT_SETTINGS, ...d.settings }; saveJSON(KEYS.settings, settings); }
        if (d.techs) { techs = d.techs; saveJSON(KEYS.techs, techs); }
        loadSettingsUI();
        updatePrefOptions();
        renderTechSelect();
        renderTechList();
        renderCodeEditor();
        renderCodeList();
        populateCategories();
        populateDatalist();
        renderHome();
        renderLog();
        toast('Import OK', 'success');
      } catch { toast('Import failed', 'error'); }
    };
    reader.readAsText(file);
  }

  // ─── Tabs ─────────────────────────────────────────────────
  function switchTab(name) {
    $$('.tab').forEach(t => t.classList.remove('active'));
    $$('.nav-btn').forEach(b => b.classList.remove('active'));
    const tab = $('#tab-' + name);
    if (tab) tab.classList.add('active');
    const btn = $(`.nav-btn[data-tab="${name}"]`);
    if (btn) btn.classList.add('active');
    const titles = { home: 'Home', book: 'Price book', job: 'Job', log: 'Log', more: 'More' };
    $('#header-title').textContent = titles[name] || name;
    if (name === 'home') renderHome();
    if (name === 'job') loadDraftToForm();
    if (name === 'log') renderLog();
    if (name === 'book') renderCodeList($('#code-search').value, $('#filter-category').value);
    if (name === 'more') {
      loadSettingsUI();
      renderTechList();
      renderCodeEditor();
    }
    const menu = $('#menu-dropdown');
    if (menu) menu.hidden = true;
  }

  // ─── Init ─────────────────────────────────────────────────
  function initApp() {
    loadData();
    loadSettingsUI();
    updatePrefOptions();
    populateCategories();
    populateDatalist();
    renderTechSelect();
    renderTechList();
    renderCodeList();
    loadDraftToForm();
    renderHome();
    renderLog();

    // Search / book
    $('#code-search').addEventListener('input', (e) => {
      renderCodeList(e.target.value, $('#filter-category').value);
    });
    $('#filter-category').addEventListener('change', () => {
      renderCodeList($('#code-search').value, $('#filter-category').value);
    });
    $('#btn-smart-find').addEventListener('click', () => {
      const results = findBestPMCodes($('#sf-hours').value, $('#sf-parts').value);
      const box = $('#smart-results');
      box.innerHTML = '';
      if (!results.length) {
        box.innerHTML = '<p class="hint">No close matches</p>';
        return;
      }
      results.forEach(c => {
        const el = document.createElement('div');
        el.className = 'code-item';
        el.innerHTML = `
          <div class="left">
            <div class="code">${c.code}</div>
            <div class="desc">${c.description || ''}</div>
            <div class="meta">parts $${c.partsCost ?? '—'} · ${c.typicalHrs ?? '—'}h</div>
          </div>
          <div class="right"><div class="price">${money(c.listPrice)}</div></div>`;
        el.addEventListener('click', () => showCodePreview(c));
        box.appendChild(el);
      });
    });

    // Preview actions
    $('#preview-close').addEventListener('click', () => { $('#preview-modal').hidden = true; });
    $('#preview-to-job').addEventListener('click', () => {
      if (previewCode) addCodeToDraft(previewCode);
      $('#preview-modal').hidden = true;
      switchTab('job');
      loadDraftToForm();
    });
    $('#preview-new-job').addEventListener('click', () => {
      if (previewCode) {
        resetDraft(previewCode);
        loadDraftToForm();
      }
      $('#preview-modal').hidden = true;
      switchTab('job');
    });

    // Job
    $('#btn-new-job').addEventListener('click', () => {
      resetDraft();
      loadDraftToForm();
      switchTab('job');
    });
    $('#btn-add-line').addEventListener('click', () => {
      $('#line-code').value = '';
      $('#line-list').value = '';
      $('#line-hrs').value = '';
      $('#line-parts').value = '0';
      $('#line-modal').hidden = false;
    });
    $('#line-code').addEventListener('change', () => {
      const c = codes.find(x => x.code.toUpperCase() === $('#line-code').value.toUpperCase());
      if (c) {
        $('#line-list').value = c.listPrice != null ? c.listPrice : '';
        $('#line-hrs').value = c.typicalHrs != null ? c.typicalHrs : '';
        $('#line-parts').value = c.partsCost != null ? c.partsCost : 0;
      }
    });
    $('#line-add').addEventListener('click', () => {
      const code = ($('#line-code').value || '').trim();
      if (!code) { toast('Code required', 'error'); return; }
      draft.lines.push({
        code,
        list: Number($('#line-list').value) || 0,
        hrs: Number($('#line-hrs').value) || 0,
        parts: Number($('#line-parts').value) || 0
      });
      saveJSON(KEYS.draft, draft);
      $('#line-modal').hidden = true;
      renderJobLines();
      toast('Line added');
    });
    $('#line-cancel').addEventListener('click', () => { $('#line-modal').hidden = true; });
    $('#line-close').addEventListener('click', () => { $('#line-modal').hidden = true; });
    $('#job-pref').addEventListener('change', () => {
      formToDraft();
      renderJobLines();
    });
    $('#job-status').addEventListener('change', () => {
      const s = $('#job-status').value;
      const badge = $('#job-status-badge');
      badge.textContent = s;
      badge.className = 'status-badge ' + s;
    });
    $('#btn-job-save').addEventListener('click', saveJob);
    $('#btn-job-clear').addEventListener('click', () => {
      if (!confirm('Clear current job draft?')) return;
      resetDraft();
      loadDraftToForm();
      toast('Draft cleared');
    });

    // Home / log
    $('#home-period').addEventListener('change', renderHome);
    $$('.stat-card.clickable').forEach(c => {
      c.addEventListener('click', () => showMetric(c.dataset.metric));
    });
    $('#metric-close').addEventListener('click', () => { $('#metric-modal').hidden = true; });
    $('#metric-close-btn').addEventListener('click', () => { $('#metric-modal').hidden = true; });
    $('#log-status').addEventListener('change', renderLog);
    $('#log-period').addEventListener('change', renderLog);
    $('#btn-shop-save').addEventListener('click', saveShopTime);

    // Tech
    $('#tech-select').addEventListener('change', (e) => {
      activeTech = e.target.value;
      localStorage.setItem(KEYS.activeTech, activeTech);
      renderHome();
      renderLog();
      toast('Viewing ' + activeTech);
    });
    $('#btn-add-tech').addEventListener('click', () => {
      const name = prompt('Technician name:');
      if (!name || !name.trim()) return;
      const n = name.trim();
      if (techs.includes(n)) { toast('Already exists', 'error'); return; }
      techs.push(n);
      saveJSON(KEYS.techs, techs);
      renderTechSelect();
      renderTechList();
      toast('Added ' + n, 'success');
    });

    // Menu
    $('#btn-menu').addEventListener('click', (e) => {
      e.stopPropagation();
      const m = $('#menu-dropdown');
      m.hidden = !m.hidden;
    });
    document.addEventListener('click', (e) => {
      const m = $('#menu-dropdown');
      if (m && !m.hidden && !$('#btn-menu').contains(e.target) && !m.contains(e.target)) m.hidden = true;
    });
    $$('#menu-dropdown button').forEach(btn => {
      btn.addEventListener('click', () => {
        const a = btn.dataset.action;
        $('#menu-dropdown').hidden = true;
        if (a === 'new-job') { resetDraft(); loadDraftToForm(); switchTab('job'); }
        if (a === 'shop-time') switchTab('log');
        if (a === 'export') exportAll();
        if (a === 'more') switchTab('more');
        if (a === 'logout') lock();
      });
    });

    // More
    $('#btn-save-security').addEventListener('click', () => {
      const p = ($('#set-pin').value || '').trim();
      if (p && (p.length < 4 || !/^\d+$/.test(p))) {
        toast('PIN must be 4–8 digits', 'error'); return;
      }
      if (p) { localStorage.setItem(KEYS.pin, p); $('#set-pin').value = ''; }
      const rec = ($('#set-recovery').value || '').trim().toUpperCase();
      if (rec) localStorage.setItem(KEYS.recovery, rec);
      toast('Security saved', 'success');
    });
    $('#btn-save-rates').addEventListener('click', () => {
      settings.laborRate = Number($('#set-labor').value) || 200;
      settings.wage = Number($('#set-wage').value) || 29;
      settings.markup = Number($('#set-markup').value) || 68;
      settings.maxPreferredDisc = Math.min(50, Number($('#set-max-disc').value) || 15);
      settings.maxDiscDollars = Number($('#set-max-dollars').value) || 200;
      settings.availHrsWeek = Number($('#set-avail').value) || 30;
      saveJSON(KEYS.settings, settings);
      updatePrefOptions();
      toast('Rates saved', 'success');
    });
    $('#btn-add-code').addEventListener('click', () => openCodeModal(-1));
    $('#modal-cancel').addEventListener('click', () => { $('#code-modal').hidden = true; });
    $('#modal-save').addEventListener('click', saveCodeModal);
    $('#btn-export').addEventListener('click', exportAll);
    $('#btn-import').addEventListener('click', () => $('#import-file').click());
    $('#import-file').addEventListener('change', (e) => {
      if (e.target.files[0]) importAll(e.target.files[0]);
    });
    $('#btn-reset-codes').addEventListener('click', () => {
      if (!confirm('Reset codes to workbook defaults?')) return;
      codes = (window.DEFAULT_CODES || []).map(c => ({ ...c }));
      saveJSON(KEYS.codes, codes);
      renderCodeEditor();
      renderCodeList();
      populateCategories();
      populateDatalist();
      toast('Codes reset', 'success');
    });

    $$('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    $('#login-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const entered = ($('#pin').value || '').trim();
      if (entered === getPin()) unlock();
      else {
        pinAttempts++;
        toast('Wrong PIN', 'error');
        $('#pin').value = '';
        $('#pin').focus();
        if (pinAttempts >= 3) $('#btn-forgot-pin').hidden = false;
      }
    });
    $('#btn-forgot-pin').addEventListener('click', () => {
      $('#forgot-panel').hidden = !$('#forgot-panel').hidden;
    });
    $('#btn-reset-pin').addEventListener('click', () => {
      const code = ($('#recovery-code').value || '').trim().toUpperCase();
      if (code === getRecovery()) {
        localStorage.setItem(KEYS.pin, DEFAULT_PIN);
        $('#recovery-code').value = '';
        $('#forgot-panel').hidden = true;
        $('#btn-forgot-pin').hidden = true;
        pinAttempts = 0;
        toast('PIN reset to 1234', 'success');
      } else toast('Incorrect recovery code', 'error');
    });

    if (sessionStorage.getItem(KEYS.unlocked) === '1') unlock();
    else $('#pin').focus();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  });
})();
